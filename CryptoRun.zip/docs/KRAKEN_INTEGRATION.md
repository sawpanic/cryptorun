# Kraken Integration

- Primary venue. REST limited to 15 calls/sec. WebSocket streaming with auto-reconnect and backoff.
- USD pairs only; exclude USDT/USDC.
- Depth/spread from exchange-native endpoints only; no aggregators.

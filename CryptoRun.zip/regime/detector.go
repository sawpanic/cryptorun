package regime

// For the slice, default to choppy when insufficient metrics are available.

func DetectDefaultChoppy() string { return "choppy" }


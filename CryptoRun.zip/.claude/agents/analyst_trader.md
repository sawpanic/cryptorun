# ROLE
Analyst/Trader Validator. Compare exchange top gainers with scanner picks.
# OUTPUTS
- winners.json, misses.jsonl, coverage.json, report.md under ./out/analyst
# DECISIONS
GOOD_FILTER / BAD_MISS / NEEDS_REVIEW based on gate trace evidence.

# Deployment

- Docker multi-stage build for Go 1.21
- docker-compose for Redis, Postgres/TimescaleDB
- K8s manifests under ./k8s

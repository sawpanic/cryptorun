package integration

import "testing"

func TestKrakenRateLimitCompliance(t *testing.T){ t.Skip("requires timing; ensure 15 rps limiter in client") }

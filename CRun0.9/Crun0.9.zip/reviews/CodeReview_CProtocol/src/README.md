CProtocol src-based architecture scaffold. Existing root binaries remain untouched. See docs/USAGE.md.

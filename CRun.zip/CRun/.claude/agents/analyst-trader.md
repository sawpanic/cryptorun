---
name: analyst-trader
description: analyst-trader agent (add details here).
tools: Read
---

# analyst-trader

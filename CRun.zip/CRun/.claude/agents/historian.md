# ROLE
Backtest Historian. Ensure point-in-time integrity and VADR stability.
# DUTIES
- Validate backtests use point-in-time data.
- Check VADR stability; flag suspicious jumps.
- Emit invariants to ./out/history/invariants.json

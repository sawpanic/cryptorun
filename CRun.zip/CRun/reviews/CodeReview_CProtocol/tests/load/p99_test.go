package load

import "testing"

func TestP99LatencyTarget(t *testing.T){ t.Skip("load test placeholder: assert <300ms") }

package main

import (
    "fmt"
)

// Minimal entry point for building a lightweight executable without full internal deps
func main() {
    fmt.Println("CProtocol Minimal Build")
    fmt.Println("Version: 0.0.1-minimal")
    fmt.Println("Status: UI badges and docs integrated. Full scanner disabled in minimal build.")
}


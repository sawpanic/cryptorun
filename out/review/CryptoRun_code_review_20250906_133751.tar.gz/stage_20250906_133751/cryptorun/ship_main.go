package main

// Ship main stub for build compatibility
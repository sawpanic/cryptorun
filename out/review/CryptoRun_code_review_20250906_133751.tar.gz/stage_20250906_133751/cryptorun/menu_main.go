package main

// MenuUI stub for build compatibility
type MenuUI struct{}

func (ui *MenuUI) Run() error {
	return nil
}

func (ui *MenuUI) handleResilientSelfTest(ctx interface{}) error {
	return nil
}

func (ui *MenuUI) handleNightlyDigest(ctx interface{}) error {
	return nil
}
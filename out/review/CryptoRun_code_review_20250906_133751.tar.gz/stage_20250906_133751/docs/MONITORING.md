# Monitoring

- Kraken venue health metrics (reject_rate, heartbeat_gap, error_rate, latency_p99)
- Circuit breaker states and probe recovery
- Cache hit rate and API usage budgets

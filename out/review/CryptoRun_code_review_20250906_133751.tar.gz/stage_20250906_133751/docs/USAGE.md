# Usage

- Build: `go build ./src/cmd/cprotocol`
- CLI commands: scan, backtest, monitor, health
- Flags: --exchange kraken, --pairs USD-only, --dry-run
- Overrides: --blacklist SYMBOL, --pause, --force-regime NAME
